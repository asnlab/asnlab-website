/*
 * @(#)AsnRuntime.h
 *
 * Copyright (c) 2009-2026, ASN Lab
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 	1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 	2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 	3. Neither the name of ASN Lab nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#pragma once

#include <chrono>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <memory>
#include <optional>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include "BigIntegerLibrary.hh"

#ifndef UNUSED
#define UNUSED(x) ((void)(x))
#endif

#if defined(_MSVC_LANG)
#define ASNRT_CPP_STANDARD _MSVC_LANG
#else
#define ASNRT_CPP_STANDARD __cplusplus
#endif

#if ASNRT_CPP_STANDARD >= 202002L
#define ASNRT_CPP20_OR_LATER 1
#else
#define ASNRT_CPP20_OR_LATER 0
#endif

namespace asnrt {

#define	ASNRT_VERSION	"v3.14.15.r20251025"
#define	ASNRT_DEBUG

/**
 * C++ STL offers a special implementation of vector< bool >, which make its elements non-addressable.
 * Hence we define our own version of boolean to make vector container consistent.
 **/
using boolean = char;
constexpr boolean TRUE  = 1;
constexpr boolean FALSE = 0;

#ifdef _MSC_VER /* VS */
	using xlong  = __int64;
	using uxlong = unsigned __int64;
	constexpr auto NL = "\r\n";
#else /* Unix */
	using xlong  = long long;
	using uxlong = unsigned long long;
	constexpr auto NL = "\n";
#endif

template<typename T>
class static_constructable {
private:
	struct helper {
		helper() {
			T::static_constructor();
		}
	};
protected:
	static_constructable() {
		static helper placeholder;
	}
};

/* Encoding rules */
enum EncodingRules : char {
	BASIC_ENCODING_RULES             = 0,
	CANONICAL_ENCODING_RULES         = 1,
	DISTINGUISHED_ENCODING_RULES     = 2,
	UNALIGNED_PACKED_ENCODING_RULES  = 3,
	ALIGNED_PACKED_ENCODING_RULES    = 4,
	OCTET_ENCODING_RULES             = 5,
	JSON_ENCODING_RULES              = 6,
	ASN_VALUE_NOTATION               = 7
};

// C++ value types for ASN.1 values

using bitstring   = std::basic_string<boolean>;
using octetstring = std::string;
using wstring     = std::basic_string<wchar_t>;
using ustring     = std::basic_string<char32_t>;
using objectid    = std::basic_string<char32_t>;

class DateTime {
public:
	DateTime();
	DateTime(xlong millisecondsSinceEpoch, int tzOffset = 0);
	DateTime(int year, int month, int day, int hour, int minute, int second, int ms, int tzOffset = 0);
	static DateTime fromUTCTime(int year, int month, int day, int hour, int minute, int second, int ms);
	DateTime toUTCTime() const;

	// ---- Getters ----
	int getYear() const; /* 1970~2037 */
	int getMonth()const ; /* 1~12 */
	int getDay()const ;  /* 1~31 */
	int getHour() const; /* 0~23 */
	int getMinute() const; /* 0~59 */
	int getSecond() const; /* 0~59 */
	int getMilliSecond() const; /* 0~999 */
	xlong getTime() const;

	// ---- Metadata ----
	/**
	 * Set the time zone offset in seconds.
	 * @param offsetSec the time zone offset in seconds.
	 */
	void setTimeZoneOffset(int seconds) { timezoneOffset = seconds; }

	/**
	 * Get the time zone offset in seconds.
	 * @return the time zone offset in seconds.
	 */
	int getTimeZoneOffset() const { return timezoneOffset; }

	bool operator==(const DateTime &t) const;

private:
	std::chrono::system_clock::time_point tp; // always stored as UTC
	int timezoneOffset; // in seconds
};

// ASN.1 Exception
enum AsnErrorCode {
	INVALID_TAG = 1,
	INVALID_LENGTH,
	INVALID_INTEGER,
	INVALID_ENUM,
	INVALID_REAL,
	OUT_OF_MEMORY,
	INVALID_TIME,
	MISSING_COMPONENT,
	EXTRA_COMPONENT,
	INVALID_INDEX,
	BUFFER_OVERFLOW,
	BUFFER_UNDERFLOW,
	INVALID_ENCODE_RULE,
	NULL_POINTER_EXCEPTION,
	NOT_PERMITTED_ALPHABET,
	NO_MATCH_INFO_OBJ,
	INVALID_LICENSE,
	INVALID_SIZE,
	IO_EXCEPTION,
	UNKNOWN_EXCEPTION,
	ABSTRACT_FUNCTION
};

#ifdef _DEBUG_
	#define ASN_EXCEPTION(errorCode, message) { throw AsnException(__FILE__, __LINE__, errorCode, message); }
	#define ASN_ERROR(errorCode) { throw AsnException(__FILE__, __LINE__, errorCode); }
#else
	#define ASN_EXCEPTION(errorCode, message) { throw AsnException(errorCode, message); }
	#define ASN_ERROR(errorCode) { throw AsnException(errorCode); }
#endif

class AsnException {
private:
	int errorCode;
	std::string message;
public:
	explicit AsnException(int code, std::string msg = "");
	explicit AsnException(const char* file, int line, int code, std::string msg = "");

	int getErrorCode() const { return errorCode; }
	const std::string& getMessage() const { return message; }

	template<typename T>
	AsnException& operator<<(const T& value) {
		std::ostringstream oss;
		oss << value;
		message += oss.str();
		return *this;
	}
};

// ASN.1 converters

class AsnBuffer;
class AsnType;

struct AsnConverter {
	virtual ~AsnConverter() {}
};

struct BooleanConverter: public AsnConverter {
	static BooleanConverter INSTANCE;
	boolean toValue(void* object);
	void toObject(void* object, boolean value);
};

struct NullConverter: public AsnConverter {
	static NullConverter INSTANCE;
};

class Codec;
class IntegerType;
struct IntegerConverter : public AsnConverter {
	virtual ~IntegerConverter() {}
	virtual void encode(void* object, IntegerType* type, Codec* codec) = 0;
	virtual void decode(void* object, IntegerType* type, Codec* codec) = 0;
};

struct IntConverter : public IntegerConverter {
	static IntConverter INSTANCE;
	int toValue(void* object);
	void toObject(void* object, int value);
	void encode(void* object, IntegerType* type, Codec* codec);
	void decode(void* object, IntegerType* type, Codec* codec);
};

struct LongConverter : public IntegerConverter {
	static LongConverter INSTANCE;
	long toValue(void* object);
	void toObject(void* object, long value);
	void encode(void* object, IntegerType* type, Codec* codec);
	void decode(void* object, IntegerType* type, Codec* codec);
};

struct XLongConverter : public IntegerConverter {
	static XLongConverter INSTANCE;
	xlong toValue(void* object);
	void toObject(void* object, xlong value);
	void encode(void* object, IntegerType* type, Codec* codec);
	void decode(void* object, IntegerType* type, Codec* codec);
};

struct BigIntegerConverter : public IntegerConverter {
	static BigIntegerConverter INSTANCE;
	BigInteger toValue(void* object);
	void toObject(void* object, const BigInteger& bi);
	void encode(void* object, IntegerType* type, Codec* codec);
	void decode(void* object, IntegerType* type, Codec* codec);
};

struct AbstractEnumeratedConverter : public AsnConverter {
	virtual ~AbstractEnumeratedConverter() {}
	virtual int toValue(void* object) = 0;
	virtual void toObject(void* object, int value) = 0;
};

template<typename _Tp>
struct EnumeratedConverter: public AbstractEnumeratedConverter {

	int toValue(void* object) override {
		_Tp* _tp = static_cast<_Tp*>(object);
		int value = *_tp;
		return value;
	}

	void toObject(void* object, int value) override {
		::new(object) _Tp(value);
	}

};

struct RealConverter: public AsnConverter {
	virtual ~RealConverter() {}
	virtual double toValue(void* object) = 0;
	virtual void toObject(void* object, double value) = 0;
};

struct FloatConverter: RealConverter {
	static FloatConverter INSTANCE;
	double toValue(void* object);
	void toObject(void* object, double value);
};

struct DoubleConverter: RealConverter {
	static DoubleConverter INSTANCE;
	double toValue(void* object);
	void toObject(void* object, double value);
};

struct BitStringConverter: public AsnConverter {
	static BitStringConverter INSTANCE;
	bitstring* toBitString(void* object);
};

struct OctetStringConverter: public AsnConverter {
	static OctetStringConverter INSTANCE;
	octetstring* toOctetString(void* object);
};

struct ObjectIdConverter: public AsnConverter {
	static ObjectIdConverter INSTANCE;
	objectid* toObjectid(void* object);
};

struct StringConverter: public AsnConverter {
	static StringConverter INSTANCE;
	std::string* toString(void* object);
};

struct WStringConverter: public AsnConverter {
	static WStringConverter INSTANCE;
	wstring* toString(void* object);
};

struct UStringConverter: public AsnConverter {
	static UStringConverter INSTANCE;
	ustring* toString(void* object);
};

struct DateTimeConverter : public AsnConverter {
	static DateTimeConverter INSTANCE;
	DateTime* toDateTime(void* object);
};

struct ListConverter : public AsnConverter {
	AsnConverter* componentConverter;
	ListConverter(): componentConverter(NULL) {}
	ListConverter(AsnConverter* componentConverter): componentConverter(componentConverter) {}

	virtual ~ListConverter() {}

	/**
	 *  Returns the number of elements in the list.
	 **/
	virtual size_t getSize(void* listObject) = 0;

	/**
	 *  Removes all of the elements from this list.
	 **/
	virtual void clearAll(void* listObject) = 0;

	/**
	 *  Adds a new element to the list.
	 **/
	virtual void* addElement(void* listObject) = 0;

	/**
	 * A new element has been decoded completed
	 **/
	virtual void doneElement(void* listObject, void* element) = 0;

	/**
	 * Returns the component at the specified index.
	 */
	virtual void* elementAt(void* listObject, size_t index) = 0;
};

template<typename _Tp>
struct VectorConverter : public ListConverter {
	using vector_type = std::vector<_Tp>;
	VectorConverter() : ListConverter() {}
	VectorConverter(AsnConverter* componentConverter) : ListConverter(componentConverter) {}
	virtual ~VectorConverter() {}

	size_t getSize(void* listObject) override {
		vector_type* _vector = static_cast<vector_type*>(listObject);
		return _vector->size();
	}

	void clearAll(void* listObject) override {
		vector_type* _vector = static_cast<vector_type*>(listObject);
		_vector->clear();
	}

	void* addElement(void* listObject) override {
		vector_type* _vector = static_cast<vector_type*>(listObject);
		_Tp t {};
		_vector->push_back(t);
		_Tp& ref = _vector->back();
		return &ref;
	}

	void doneElement(void* listObject, void* element) override { UNUSED(listObject); UNUSED(element); }

	void* elementAt(void* listObject, size_t index) override {
		vector_type* _vector = static_cast<vector_type*>(listObject);
		_Tp& ref =_vector->at(index);
		return &ref;
	}

};

// Helper trait: detect raw pointer
template<typename T> struct is_raw_ptr : std::false_type {};
template<typename U> struct is_raw_ptr<U*> : std::true_type {};

// Helper trait: detect std::optional
template<typename T> struct is_optional : std::false_type {};
template<typename U> struct is_optional<std::optional<U>> : std::true_type {};

// Helper trait: detect std::unique_ptr
template<typename T> struct is_unique_ptr : std::false_type {};
template<typename U> struct is_unique_ptr<std::unique_ptr<U>> : std::true_type {};

// Helper trait: detect std::shared_ptr
template<typename T> struct is_shared_ptr : std::false_type {};
template<typename U> struct is_shared_ptr<std::shared_ptr<U>> : std::true_type {};

template<typename T>
struct is_plain_value
	: std::bool_constant<
		  std::is_object_v<T> &&
		  !is_raw_ptr<T>::value &&
		  !is_optional<T>::value &&
		  !is_unique_ptr<T>::value && 
		  !is_shared_ptr<T>::value
	> {};

// Specialize for abstract base pointer types
template<> struct is_raw_ptr<AsnType*> : std::false_type {};
template<> struct is_plain_value<AsnType*> : std::true_type {};

// Traits for detection of variants
template<typename T> struct is_std_variant : std::false_type {};
template<typename...Ts> struct is_std_variant<std::variant<Ts...>> : std::true_type {};

// Traits to extract Composite and Field from a pointer-to-member.
template<typename T> struct member_pointer_traits;

template<typename C, typename F>
struct member_pointer_traits<F C::*> {
	using composite_type = C;
	using field_type     = F;
};

struct ValueHandler {
	// Get: returns pointer to the direct value or nullptr if not present.
	// Argument: void* pointer to value, which may be plain value, raw pointer, 
	// std::optional, std::unique_ptr or std::shared_ptr. p is always not null.
	std::function<void*(void* p)> get;

	// Create: returns pointer to the value if it is a plain value, otherwise
	// create and return the pointer to the direct value. Always not null.
	// Argument: void* pointer to value, which may be plain value, raw pointer, 
	// std::optional, std::unique_ptr or std::shared_ptr. p is always not null.
	std::function<void*(void* p)> create;

	// Free: cleans up owned resource if needed.
	// Argument: void* pointer to value, which may be plain value, raw pointer, 
	// std::optional, std::unique_ptr or std::shared_ptr. p is always not null.
	// Default is no-op.
	std::function<void(void* p)> free = [](void*){};
};

template<typename Get, typename Create, typename Free>
ValueHandler make_value_handler(Get get, Create create, Free free) {
#if ASNRT_CPP20_OR_LATER
	return {
		.get = std::move(get),
		.create = std::move(create),
		.free = std::move(free)
	};
#else
	ValueHandler handler;
	handler.get = std::move(get);
	handler.create = std::move(create);
	handler.free = std::move(free);
	return handler;
#endif
}

// =================================================
//  create_handler  (overloads chosen by SFINAE)
// =================================================

inline const ValueHandler idempotent_handler = make_value_handler(
	[](void* vp) -> void* { return vp; },
	[](void* vp) -> void* { return vp; },
	[](void* vp) { UNUSED(vp); /* no-op */ }
);

// ---- plain value --------------------------------
template<class T>
std::enable_if_t<is_plain_value<T>::value, const ValueHandler&> create_handler() {
	return idempotent_handler;
}

// ---- raw pointer --------------------------------
template<class T>
std::enable_if_t<is_raw_ptr<T>::value, ValueHandler> create_handler() {
	using Pointee = std::remove_pointer_t<T>;
	return make_value_handler(
		[](void* vp) -> void* {
			auto* pp = static_cast<T*>(vp);
			return *pp; // may be nullptr
		},
		[](void* vp) -> void* {
			auto* pp = static_cast<T*>(vp);
			*pp = new Pointee();
			return *pp;
		},
		[](void* vp) {
			auto* pp = static_cast<T*>(vp);
			if (*pp)
			{
				delete *pp;
			}
			*pp = nullptr;
		}
	);
}

// ---- std::optional ------------------------------
template<class T>
std::enable_if_t<is_optional<T>::value, ValueHandler> create_handler() {
	using Opt = T;
	return make_value_handler(
		[](void* vp) -> void* {
			auto* opt = static_cast<Opt*>(vp);
			return opt->has_value() ? &opt->value() : nullptr;
		},
		[](void* vp) -> void* {
			auto* opt = static_cast<Opt*>(vp);
			opt->emplace();
			return &opt->value();
		},
		[](void* vp) {
			auto* opt = static_cast<Opt*>(vp);
			opt->reset();
		}
	);
}

// ---- std::unique_ptr ----------------------------
template<class T>
std::enable_if_t<is_unique_ptr<T>::value, ValueHandler> create_handler() {
	using UP = T;
	using V  = typename UP::element_type;
	return make_value_handler(
		[](void* vp) -> void* {
			auto* up = static_cast<UP*>(vp);
			return up->get();
		},
		[](void* vp) -> void* {
			auto* up = static_cast<UP*>(vp);
			*up = std::make_unique<V>();
			return up->get();
		},
		[](void* vp) {
			auto* up = static_cast<UP*>(vp);
			up->reset();
		}
	);
}

// ---- std::shared_ptr ----------------------------
template<typename T>
std::enable_if_t<is_shared_ptr<T>::value, ValueHandler> create_handler() {
	using Pointee = typename T::element_type;
	return make_value_handler(
		[](void* vp) -> void* {
			auto& sp = *static_cast<T*>(vp);
			return sp.get();
		},
		[](void* vp) -> void* {
			auto& sp = *static_cast<T*>(vp);
			sp = std::make_shared<Pointee>();
			return sp.get();
		},
		[](void* vp) {
			auto& sp = *static_cast<T*>(vp);
			sp.reset();
		}
	);
}

// ---- std::variant ----------------------------
template<size_t Index, typename Variant>
ValueHandler create_handler_for_variant() {
	using AltType = std::variant_alternative_t<Index, Variant>;
	ValueHandler alt_handler = create_handler<AltType>();

	return make_value_handler(
		// get pointer to the active alternative; nullptr if inactive
		[alt_handler](void* vp) -> void* {
			Variant* v = static_cast<Variant*>(vp);
			if (AltType* p = std::get_if<Index>(v)) {
				return alt_handler.get(p);
			}
			return nullptr;
		},

		// create (emplace) the alternative if not already active
		[alt_handler](void* vp) -> void* {
			Variant* v = static_cast<Variant*>(vp);
			v->template emplace<Index>(); // construct default alternative
			AltType* p = &std::get<Index>(*v);
			return alt_handler.create(p);
		},
		[alt_handler](void* vp) {
			Variant* v = static_cast<Variant*>(vp);
			if (AltType* p = std::get_if<Index>(v)) {
				alt_handler.free(p);
			}
		}
	);
}

struct FieldDescriptor {
	size_t index;
	std::function<void*(void*)> accessor;
	ValueHandler handler;
	AsnConverter* converter = nullptr;
#ifdef ASNRT_DEBUG
	const char* name = nullptr;
#endif
};

template<size_t Index, typename Composite, typename Component>
FieldDescriptor create_component(Component Composite::* component, AsnConverter* conv, const char* name)
{
	FieldDescriptor fd{};
	fd.index     = Index;
	fd.converter = conv;
#ifdef ASNRT_DEBUG
	fd.name = name;
#endif

	fd.accessor = [component](void* composite) -> void* {
		Composite* c = static_cast<Composite*>(composite);
		return &(c->*component);
	};

	fd.handler = create_handler<Component>();
	return fd;
}

template<size_t Index, typename UnionHolder, typename AltType>
FieldDescriptor create_alternative_for_union(AltType decltype(UnionHolder::value)::* alternative, AsnConverter* conv, const char* name)
{
	using Union = decltype(UnionHolder::value);
	FieldDescriptor fd{};
	fd.index     = Index;
	fd.converter = conv;
#ifdef ASNRT_DEBUG
	fd.name = name;
#endif

	fd.accessor = [alternative](void* choice) -> void* {
		UnionHolder* h = static_cast<UnionHolder*>(choice);
		Union* u = &(h->value);
		return &(u->*alternative);
	};

	fd.handler = create_handler<AltType>();
	return fd;
}

template<size_t Index, typename Variant>
FieldDescriptor create_alternative_for_variant(AsnConverter* conv, const char* name)
{
	FieldDescriptor fd{};
	fd.index     = Index;
	fd.converter = conv;
#ifdef ASNRT_DEBUG
	fd.name = name;
#endif

	fd.accessor = [](void* choice) -> void* {
		return choice;
	};

	fd.handler = create_handler_for_variant<Index, Variant>();
	return fd;
}

struct CompositeConverter : public AsnConverter {
	FieldDescriptor* components;
	CompositeConverter(): components(nullptr) {}
	CompositeConverter(FieldDescriptor* components): components(components) {}
	virtual ~CompositeConverter() {}
	virtual AsnConverter* getComponentConverter(size_t index);
	virtual void* getComponentObject(void* composite, size_t index);
	virtual void* createComponentObject(void* composite, size_t index);
	virtual void doneComponentObject(void* composite, size_t index);
};

struct ChoiceConverter : public AsnConverter {
	FieldDescriptor* alternatives;
	ChoiceConverter(): alternatives(nullptr) {}
	ChoiceConverter(FieldDescriptor* alternatives): alternatives(alternatives) {}
	virtual ~ChoiceConverter() {}
	virtual size_t getAlternativeIndex(void* choice) = 0;
	virtual void* getAlternativeObject(void* choice);
	virtual void* createAlternativeObject(void* choice, size_t index);
};

template<typename UnionHolder>
struct UnionChoiceConverter : public ChoiceConverter {
	UnionChoiceConverter() {}
	UnionChoiceConverter(FieldDescriptor* alternativeDescriptors): ChoiceConverter(alternativeDescriptors) {}
	virtual ~UnionChoiceConverter() {}
	inline size_t getAlternativeIndex(void* choice) override {
		UnionHolder* h = static_cast<UnionHolder*>(choice);
		return h->choice;
	}
	inline void* createAlternativeObject(void* choice, size_t index) override {
		UnionHolder* h = static_cast<UnionHolder*>(choice);
		h->choice = index;
		return ChoiceConverter::createAlternativeObject(choice, index);
	}
};

template<typename _Variant>
struct VariantChoiceConverter : public ChoiceConverter {
	VariantChoiceConverter(): ChoiceConverter() {}
	VariantChoiceConverter(FieldDescriptor* alternatives): ChoiceConverter(alternatives) {}
	virtual ~VariantChoiceConverter() {}
	inline size_t getAlternativeIndex(void* choice) override {
		_Variant* v = static_cast<_Variant*>(choice);
		return v->index();
	}
};

struct OpenValueConverter : public AsnConverter {
	FieldDescriptor* variants;
	size_t numOfVariants;
	OpenValueConverter(FieldDescriptor* variants, size_t n):
		variants(variants), numOfVariants(n)  {}
	virtual ~OpenValueConverter() {}
	FieldDescriptor* getFieldDescriptor(size_t index);
	FieldDescriptor* getRawFieldDescriptor();
};

// Useful macros and templates

#define DECLARE_TYPE() \
public:	static AsnType* TYPE

#define DECLARE_COMPOSITE_CONVERTER(ConverterClass) \
public: static FieldDescriptor _ComponentDescriptors_[]; \
public:	static ConverterClass CONVERTER

#define DECLARE_CHOICE_CONVERTER(ConverterClass) \
public: static FieldDescriptor _AlternativeDescriptors_[]; \
public:	static ConverterClass CONVERTER

#define DECLARE_OPEN_CONVERTER(component) \
public: \
	static FieldDescriptor _##component##ActualValueDescriptors_[]; 	\
	static OpenValueConverter _##component##Converter


#define ASN_COMPONENT(Index, Composite, component, converter) create_component<Index, Composite>(&Composite::component, converter, #Composite "::" #component)


#define ASN_ALTERNATIVE_UNION(Index, Holder, Member, converter) \
    create_alternative_for_union<Index, Holder>(&std::remove_reference_t<decltype(Holder::value)>::Member, converter, #Holder "::value::" #Member)

#define ASN_ALTERNATIVE_VARIANT(Index, Choice, converter) \
    create_alternative_for_variant<Index, Choice>(converter, #Choice "<" #Index ">")

#define ASN_ALTERNATIVE_SELECT(_1,_2,_3,_4, NAME, ...) NAME

// Union form:     ASN_ALTERNATIVE(Index, Union, alternative, Converter)
// Variant form:   ASN_ALTERNATIVE(Index, Variant, Converter)
#define ASN_ALTERNATIVE(...) \
    ASN_ALTERNATIVE_SELECT(__VA_ARGS__, \
                           ASN_ALTERNATIVE_UNION,  /* 4 args */ \
                           ASN_ALTERNATIVE_VARIANT /* 3 args */ \
                          )(__VA_ARGS__)

#define ASN_VARIANT(Index, Variant, converter) create_alternative_for_variant<Index, Variant>(converter, #Variant "<" #Index ">")

#define ASN_COMPOSITE(ConverterClass, CompositeClass, ...) 	\
	FieldDescriptor CompositeClass::_ComponentDescriptors_[] = {	\
		__VA_ARGS__ \
	};	\
	ConverterClass CompositeClass::CONVERTER(_ComponentDescriptors_)

#define ASN_CHOICE(ConverterClass, ChoiceClass, ...) \
	FieldDescriptor ChoiceClass::_AlternativeDescriptors_[] = {	\
		__VA_ARGS__ \
	};	\
	ConverterClass ChoiceClass::CONVERTER(_AlternativeDescriptors_)

#define ASN_OPEN_TYPE(CompositeClass, component, ...) \
	FieldDescriptor CompositeClass::_##component##ActualValueDescriptors_[] = {	\
		__VA_ARGS__ \
	};	\
	OpenValueConverter CompositeClass::_##component##Converter(_##component##ActualValueDescriptors_, sizeof(_##component##ActualValueDescriptors_)/sizeof(FieldDescriptor))


struct AsnTriplet {
	void* object;
	AsnType* type;
	AsnConverter* converter;
	int typeId;
};


// Public API

/* Buffer Allocation */

/**
 * Wraps an array into a buffer, basically, this buffer is for decoding.
 *
 * The new buffer will be backed by the given byte array;
 * that is, modifications to the buffer will cause the array to be modified and vice versa.
 * For Basic Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes</tt>,
 * and for Pack Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes*8</tt>.
 * 
 * @param array the byte array that the new buffer will be backed by
 * @param numBytes the size of the byte array
 * @param encodingRules the encoding rules to use, either Basic Encoding Rules or Pack Encoding Rules
 * @return the new buffer backed by the byte array
 *
 */
AsnBuffer* wrap_buffer(char* array, size_t numBytes, char encodingRules);

/**
 * Allocates a new buffer, basically, this buffer is for encoding.
 *
 * For Basic Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes</tt>,
 * and for Pack Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes*8</tt>.
 */
AsnBuffer* alloc_buffer(size_t numBytes, bool autoExpand, char encodingRules);

/**
 * Create a buffer out of an istream, this buffer is for decoding.
 */
AsnBuffer* istream_buffer(std::istream* in, size_t numBytes, char encodingRules);

/**
 * Create a buffer out of an ostream, this buffer is for encoding.
 */
AsnBuffer* ostream_buffer(std::ostream* out, size_t numBytes, char encodingRules);

/**
 * Get the buffer's encoding content
 */
void buffer_content(AsnBuffer* buffer, octetstring* content);

/**
 * Free a buffer. The memory of byte array and the buffer itself will
 * be freed.
 */
void free_buffer(AsnBuffer*& buffer);


/* Encoding/Decoding Routines */

/**
 * Encode the object with encoding rules specified in the buffer
 **/
void encode_object(AsnBuffer* buffer, void* object, AsnType* type, AsnConverter* converter);

/**
 * Decode the object with encoding rules specified in the buffer
 **/
void decode_object(AsnBuffer* buffer, void* object, AsnType* type, AsnConverter* converter);


/*  Utilities Routines */

/**
 * print the object as ASN.1 value
 **/
void print_object(const void* object, AsnType* type, AsnConverter* converter, std::ostream* out);

/**
 * determine if the two object equal as ASN.1 value
 **/
bool equals_to(const void* o1, const void* o2, AsnType* type, AsnConverter* converter);

/**
 * deep clone object o2 to o1 as ASN.1 value
 * that is o1 = o2
 **/
void clone_object(const void* o1, const void* o2, AsnType* type, AsnConverter* converter);

/**
 * deep free object content
 **/
void free_object(void* object, AsnType* type, AsnConverter* converter);


// ASN.1 Runtime Project

class AsnProject {
public:
	AsnProject();
	explicit AsnProject(const char* metafile);
	explicit AsnProject(octetstring metaContent);
	virtual ~AsnProject();

	AsnType* getType(long id);
	int getValue(void* value, long valueId, AsnConverter* converter);
private:
	struct Impl;
	Impl* pImpl;
};

// ~END

}

